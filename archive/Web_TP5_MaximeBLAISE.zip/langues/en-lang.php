<?php

define("TXT_PATATES", "I find very dommage, that we have no fromage. However I constate, that there are some patates");
define("NOMBRE", "Number of potatoes : ");
define("NOMBREDEF", "Default : 5");
define("FORMGET", "Formulaire with GET method");
define("FORMPOST", "Formulaire with POST method");
define("VALIDERGET", "Submit with GET");
define("VALIDERPOST", "Submit with POST");
define("BOUTONFR", "French");
define("BOUTONEN", "English");