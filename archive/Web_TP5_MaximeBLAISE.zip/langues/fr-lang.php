<?php

define("TXT_PATATES", "Je trouve ça dommage, qu'on n'ait pas de fromage. Par contre je constate, qu'il y a des patates.");
define("NOMBRE", "Nombre de patates : ");
define("NOMBREDEF", "Par défaut : 5");
define("FORMGET", "Formulaire avec la méthode GET");
define("FORMPOST", "Formulaire avec la méthode POST");
define("VALIDERGET", "Valider avec GET");
define("VALIDERPOST", "Valider avec POST");
define("BOUTONFR", "Francais");
define("BOUTONEN", "Anglais");