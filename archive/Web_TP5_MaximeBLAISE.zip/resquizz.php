<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"> 

<html xmlns="http://www.w3.org/1999/xhtml">   

    <head>    
        <title>Quizz</title>   
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />  
        <link rel="stylesheet" type="text/css" href="css/style.css" />
    </head> 

    <body>  
        
        <h1>
            Cette partie n'est pas encore implémentée.
            Donc on va dire que vous avez gagné le Quizz !
        </h1>

        <p>
            <a href="quizz.php" >Retour au Quizz</a>
        </p>
    </body> 
</html> 
