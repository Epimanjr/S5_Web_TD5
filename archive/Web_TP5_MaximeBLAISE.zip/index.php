<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"> 

<html xmlns="http://www.w3.org/1999/xhtml">   

    <head>    
        <title>Quizz</title>   
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />  
        <link rel="stylesheet" type="text/css" href="css/style.css" />
    </head> 

    <body>  
        
        <h1>
            Bienvenue sur l'accueil du TD5 du cours Programmation Web !
        </h1>

        <p>
            <a href="patates.php" >Lien vers l'exercice 1 sur les patates</a>
        </p>
        <p>
            <a href="quizz.php" >Lien vers l'exercice 2 sur le quizz</a>
        </p>
    </body> 
</html> 
